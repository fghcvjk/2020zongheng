#!/bin/bash
python2 -u -c "import maze"


