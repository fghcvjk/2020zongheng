#!/bin/bash
ulimit -c 0      # core dump size (kb)
ulimit -t 60     # max cpu using (s/min)
ulimit -u 1500    # max number of process
ulimit -m 512000 # max memory (kb)

cd /home/ctf
stdbuf -oL echo -n "Please enter your IP:"
read IP
echo $IP|grep "^[0-9\.]\{7,15\}$" > /dev/null
if [ $? -ne 0 ]
then
    stdbuf -oL echo "Please input a IP!"
else
    exec /home/ctf/wget -P /tmp $IP
fi
