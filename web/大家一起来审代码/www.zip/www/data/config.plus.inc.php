<?php
$PLUS=array (
  'HideVideo' => 
  array (
    'off' => '',
    'data' => 
    array (
      0 => '0',
    ),
    'info' => '应版权方要求此视频已下架，请支持正版！ -  {seacms:sitename}',
  ),
  'JmpVideo' => 
  array (
    'off' => '',
    'data' => 
    array (
      0 => '1',
    ),
  ),
  'Other' => 
  array (
    'numPerPage' => '20',
  ),
  'HideName' => 
  array (
    'off' => '',
    'data' => 
    array (
      0 => '屏蔽词',
    ),
    'info' => '因政策原因，该影片已经被系统屏蔽！-  {seacms:sitename}',
  ),
  'HideType' => 
  array (
    'off' => '',
    'data' => 
    array (
      0 => '0',
    ),
    'info' => '当前分类视频必须使用手机播放！-  {seacms:sitename}',
  ),
);
