<?php
//数据库连接信息
$cfg_dbhost = '127.0.0.1';
$cfg_dbname = 'seacms';
$cfg_dbuser = 'admin';
$cfg_dbpwd = 'admin';
$cfg_dbprefix = 'sea_';
$cfg_db_language = 'utf8';
?>