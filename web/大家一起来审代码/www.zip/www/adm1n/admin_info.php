<?php
require_once(dirname(__FILE__) . "/config.php");
require_once(sea_DATA . "/config.user.inc.php");
include(sea_ADMIN.'/templets/admin_info.htm');
?>